import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DataService {
  private data: { userName: string, mealPreference: string } = { userName: '', mealPreference: '' };

  setData(data: { userName: string, mealPreference: string }) {
    this.data = data;
  }

  getData() {
    return this.data;
  }
}