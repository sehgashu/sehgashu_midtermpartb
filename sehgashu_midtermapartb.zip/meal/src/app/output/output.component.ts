import { Component } from '@angular/core';
import { DataService } from '../data.service';

@Component({
  selector: 'app-output',
  templateUrl: './output.component.html',
  styleUrls: ['./output.component.css']
})
export class OutputComponent {
  userName: string = '';
  mealPreference: string = '';

  constructor(private dataService: DataService) {
    const data = this.dataService.getData();
    this.userName = data.userName;
    this.mealPreference = data.mealPreference;
  }
}