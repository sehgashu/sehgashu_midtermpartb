import { Component } from '@angular/core';
import { DataService } from '../data.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-input',
  templateUrl: './input.component.html',
  styleUrls: ['./input.component.css']
})
export class InputComponent {
  userName: string = '';
  mealPreference: string = '';

  constructor(private dataService: DataService, private router: Router) { }

  submitForm() {
    this.dataService.setData({
      userName: this.userName,
      mealPreference: this.mealPreference
    });

    this.router.navigate(['/output']);
  }
}
